/// واحد قیمت‌ها که کنار هر عدد نمایش داده میشه.
/// اگه قیمت‌ها ریال هستن همین‌جا بنویس 'ریال'.
const String kUnit = 'تومان';

const String _faDigits = '۰۱۲۳۴۵۶۷۸۹';
const String _arDigits = '٠١٢٣٤٥٦٧٨٩';
const String _alphabet = 'اآبپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی';

/// یکدست‌سازی متن برای جستجو: ي/ك عربی، اعداد فارسی و عربی، فاصله‌ها
String normalizeFa(String input) {
  var s = input.toLowerCase();
  s = s
      .replaceAll('ي', 'ی')
      .replaceAll('ى', 'ی')
      .replaceAll('ك', 'ک')
      .replaceAll('ۀ', 'ه')
      .replaceAll('ة', 'ه')
      .replaceAll('\u200c', ' ');
  for (var i = 0; i < 10; i++) {
    s = s.replaceAll(_faDigits[i], '$i').replaceAll(_arDigits[i], '$i');
  }
  return s.replaceAll(RegExp(r'\s+'), ' ').trim();
}

/// تبدیل اعداد انگلیسی داخل متن به فارسی
String toFaDigits(String s) {
  final b = StringBuffer();
  for (final r in s.runes) {
    if (r >= 48 && r <= 57) {
      b.write(_faDigits[r - 48]);
    } else {
      b.writeCharCode(r);
    }
  }
  return b.toString();
}

/// ۷۲۰۰۰ -> ۷۲٬۰۰۰
String formatPrice(int v) {
  final s = v.toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write('٬');
    b.write(s[i]);
  }
  return toFaDigits(b.toString());
}

int _rank(String ch) {
  final i = _alphabet.indexOf(ch);
  return i >= 0 ? 1000 + i : ch.codeUnitAt(0);
}

/// مقایسه الفبایی فارسی (پ چ ژ گ سر جای درستشون)
int compareFa(String a, String b) {
  final x = normalizeFa(a);
  final y = normalizeFa(b);
  final n = x.length < y.length ? x.length : y.length;
  for (var i = 0; i < n; i++) {
    final cx = _rank(x[i]);
    final cy = _rank(y[i]);
    if (cx != cy) return cx.compareTo(cy);
  }
  return x.length.compareTo(y.length);
}

List<String> queryTokens(String q) {
  final n = normalizeFa(q);
  if (n.isEmpty) return const [];
  return n.split(' ').where((t) => t.isNotEmpty).toList();
}

/// خوندن CSV (کاما یا نقطه‌ویرگول، پشتیبانی از گیومه و BOM)
List<List<String>> parseCsv(String text) {
  final s = text.startsWith('\uFEFF') ? text.substring(1) : text;
  var firstLine = s;
  final nl = s.indexOf('\n');
  if (nl >= 0) firstLine = s.substring(0, nl);
  final delim = (!firstLine.contains(',') && firstLine.contains(';')) ? ';' : ',';

  final rows = <List<String>>[];
  var row = <String>[];
  final field = StringBuffer();
  var inQuotes = false;
  for (var i = 0; i < s.length; i++) {
    final ch = s[i];
    if (inQuotes) {
      if (ch == '"') {
        if (i + 1 < s.length && s[i + 1] == '"') {
          field.write('"');
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field.write(ch);
      }
    } else if (ch == '"') {
      inQuotes = true;
    } else if (ch == delim) {
      row.add(field.toString());
      field.clear();
    } else if (ch == '\n') {
      row.add(field.toString());
      field.clear();
      rows.add(row);
      row = <String>[];
    } else if (ch != '\r') {
      field.write(ch);
    }
  }
  if (field.isNotEmpty || row.isNotEmpty) {
    row.add(field.toString());
    rows.add(row);
  }
  return rows;
}

class Category {
  Category({required this.id, required this.name, required this.index});

  final String id;
  final String name;
  final int index;
  final List<Item> items = [];
}

class Item {
  Item({
    required this.code,
    required this.name,
    required this.price,
    required this.category,
  }) : key = normalizeFa(name);

  final String code;
  final String name;
  final int price;
  final Category category;
  final String key;

  bool matches(List<String> tokens) {
    for (final t in tokens) {
      if (!key.contains(t) && !code.contains(t)) return false;
    }
    return true;
  }
}

class Catalog {
  Catalog(this.categories) {
    for (final c in categories) {
      for (final it in c.items) {
        byKey.putIfAbsent(it.key, () => <Item>[]).add(it);
      }
    }
  }

  final List<Category> categories;
  final Map<String, List<Item>> byKey = {};

  int get totalItems {
    var n = 0;
    for (final c in categories) {
      n += c.items.length;
    }
    return n;
  }

  /// ساخت از فایل CSV با ستون‌های: لیست, کد, نام, قیمت
  factory Catalog.fromCsv(String text) {
    final rows = parseCsv(text);
    final cats = <Category>[];
    final byName = <String, Category>{};
    for (final row in rows) {
      if (row.length < 4) continue;
      final listName = row[0].trim();
      final code = row[1].trim();
      final name = row[2].trim();
      final priceHead = row[3].trim().toLowerCase();
      if (priceHead == 'price' || priceHead == 'قیمت') continue; // سطر عنوان
      if (listName.isEmpty || name.isEmpty) continue;
      final priceText =
          normalizeFa(row[3]).replaceAll(RegExp(r'[٬,،\s]'), '');
      final price = double.tryParse(priceText)?.round() ?? 0;
      var cat = byName[listName];
      if (cat == null) {
        cat = Category(id: listName, name: listName, index: cats.length);
        byName[listName] = cat;
        cats.add(cat);
      }
      cat.items.add(Item(code: code, name: name, price: price, category: cat));
    }
    return Catalog(cats);
  }

  /// اگه فایل خراب یا خالی بود null برمی‌گردونه
  static Catalog? tryParse(String text) {
    try {
      final c = Catalog.fromCsv(text);
      return c.totalItems >= 5 ? c : null;
    } catch (_) {
      return null;
    }
  }

  /// جستجو در همه‌ی لیست‌ها
  List<Item> search(String q, {int limit = 300}) {
    final tokens = queryTokens(q);
    if (tokens.isEmpty) return const [];
    final out = <Item>[];
    for (final c in categories) {
      for (final it in c.items) {
        if (it.matches(tokens)) {
          out.add(it);
          if (out.length >= limit) return out;
        }
      }
    }
    return out;
  }

  /// همین ظرف (با همین اسم) در لیست‌های دیگه
  List<Item> othersWithSameName(Item item) {
    final all = byKey[item.key] ?? const <Item>[];
    return all.where((o) => o.category != item.category).toList();
  }
}
