import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'category_page.dart';
import 'data_store.dart';
import 'models.dart';
import 'style.dart';
import 'widgets.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DishPricesApp());
}

class DishPricesApp extends StatelessWidget {
  const DishPricesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HexPrice',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      themeMode: ThemeMode.system,
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      home: const LoaderPage(),
    );
  }
}

const List<Color> _headerColors = [
  Color(0xFF0B4F6C),
  Color(0xFF0F766E),
  Color(0xFF14B8A6),
];

class LoaderPage extends StatefulWidget {
  const LoaderPage({super.key});

  @override
  State<LoaderPage> createState() => _LoaderPageState();
}

class _LoaderPageState extends State<LoaderPage> {
  Catalog? _catalog;
  String _raw = '';
  bool _failed = false;
  bool _refreshing = false;

  static const String _msgUpdated = 'قیمت‌ها به‌روز شد';

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final text = await DataStore.loadLocal();
      final c = Catalog.fromCsv(text);
      if (!mounted) return;
      setState(() {
        _catalog = c;
        _raw = text;
      });
    } catch (_) {
      if (mounted) setState(() => _failed = true);
      return;
    }
    await _refresh(silent: true);
  }

  Future<void> _refresh({bool silent = false}) async {
    if (_refreshing) return;
    setState(() => _refreshing = true);
    String msg;
    try {
      final text = await DataStore.fetchRemote();
      if (text == null) {
        msg = 'اتصال برقرار نشد؛ لیست قبلی نمایش داده میشه';
      } else {
        final c = Catalog.tryParse(text);
        if (c == null) {
          msg = 'فایل قیمت‌ها معتبر نبود';
        } else if (text.trim() == _raw.trim()) {
          msg = 'لیست قیمت‌ها به‌روزه';
        } else {
          await DataStore.save(text);
          if (mounted) {
            setState(() {
              _catalog = c;
              _raw = text;
            });
          }
          msg = _msgUpdated;
        }
      }
    } catch (_) {
      msg = 'خطا در به‌روزرسانی';
    }
    if (!mounted) return;
    setState(() => _refreshing = false);
    if (!silent || msg == _msgUpdated) {
      final messenger = ScaffoldMessenger.of(context);
      messenger.hideCurrentSnackBar();
      messenger.showSnackBar(SnackBar(content: Text(msg)));
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget child;
    if (_catalog != null) {
      child = HomePage(
        key: const ValueKey('home'),
        catalog: _catalog!,
        refreshing: _refreshing,
        onRefresh: () => _refresh(),
      );
    } else if (_failed) {
      child = const Scaffold(
        key: ValueKey('error'),
        body: Center(child: Text('خطا در بارگذاری اطلاعات')),
      );
    } else {
      child = const _Splash(key: ValueKey('splash'));
    }
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 350),
      child: child,
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: _headerColors,
          ),
        ),
        child: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _Logo(size: 132, radius: 30),
              SizedBox(height: 16),
              Text(
                'HexPrice',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({
    super.key,
    required this.catalog,
    required this.refreshing,
    required this.onRefresh,
  });

  final Catalog catalog;
  final bool refreshing;
  final VoidCallback onRefresh;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _ctrl = TextEditingController();
  String _q = '';

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _open(Category c) {
    FocusScope.of(context).unfocus();
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => CategoryPage(catalog: widget.catalog, category: c),
      ),
    );
  }

  Widget _header(BuildContext context) {
    final cats = widget.catalog.categories;
    return Container(
      padding: EdgeInsets.fromLTRB(
        20,
        MediaQuery.of(context).padding.top + 20,
        20,
        22,
      ),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: _headerColors,
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const _Logo(size: 52, radius: 14),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'HexPrice',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      'لیست قیمت ظروف',
                      style: TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                  ],
                ),
              ),
              if (widget.refreshing)
                const Padding(
                  padding: EdgeInsets.all(12),
                  child: SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: Colors.white,
                    ),
                  ),
                )
              else
                IconButton(
                  tooltip: 'به‌روزرسانی قیمت‌ها',
                  onPressed: widget.onRefresh,
                  icon: const Icon(Icons.refresh, color: Colors.white),
                ),
            ],
          ),
          const SizedBox(height: 18),
          TextField(
            controller: _ctrl,
            onChanged: (v) => setState(() => _q = v),
            textInputAction: TextInputAction.search,
            style: const TextStyle(color: Color(0xFF111827)),
            decoration: InputDecoration(
              hintText: 'جستجوی ظرف در همه‌ی لیست‌ها…',
              hintStyle: const TextStyle(color: Color(0xFF6B7280)),
              prefixIcon: const Icon(Icons.search, color: Color(0xFF6B7280)),
              suffixIcon: _q.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close, color: Color(0xFF6B7280)),
                      onPressed: () {
                        _ctrl.clear();
                        setState(() => _q = '');
                      },
                    ),
              filled: true,
              fillColor: Colors.white,
              contentPadding: const EdgeInsets.symmetric(vertical: 14),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            '${toFaDigits('${cats.length}')} لیست  ·  '
            '${toFaDigits('${widget.catalog.totalItems}')} کالا',
            style: const TextStyle(color: Colors.white70, fontSize: 12),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cats = widget.catalog.categories;
    final searching = _q.trim().isNotEmpty;
    final results = searching ? widget.catalog.search(_q) : const <Item>[];

    final List<Widget> slivers = [
      SliverToBoxAdapter(child: _header(context)),
    ];

    if (!searching) {
      slivers.add(
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 28),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 240,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.2,
            ),
            delegate: SliverChildBuilderDelegate(
              (context, i) => _CategoryCard(
                category: cats[i],
                onTap: () => _open(cats[i]),
              ),
              childCount: cats.length,
            ),
          ),
        ),
      );
    } else if (results.isEmpty) {
      slivers.add(
        const SliverFillRemaining(
          hasScrollBody: false,
          child: Center(child: Text('موردی پیدا نشد')),
        ),
      );
    } else {
      slivers.add(
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(12, 16, 12, 28),
          sliver: SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, i) => ItemTile(
                catalog: widget.catalog,
                item: results[i],
                showCategory: true,
              ),
              childCount: results.length,
            ),
          ),
        ),
      );
    }

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        body: CustomScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          slivers: slivers,
        ),
      ),
    );
  }
}

class _CategoryCard extends StatelessWidget {
  const _CategoryCard({required this.category, required this.onTap});

  final Category category;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final g = gradientFor(category.index);
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: Material(
        color: Colors.transparent,
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: g,
            ),
          ),
          child: InkWell(
            onTap: onTap,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Positioned(
                  left: -14,
                  bottom: -14,
                  child: Icon(
                    iconFor(category.index),
                    size: 96,
                    color: Colors.white.withAlpha(38),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: Colors.white.withAlpha(51),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          iconFor(category.index),
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            category.name,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${toFaDigits('${category.items.length}')} کالا',
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Logo extends StatelessWidget {
  const _Logo({required this.size, required this.radius});

  final double size;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Image.asset(
        'assets/icon/logo.png',
        width: size,
        height: size,
        fit: BoxFit.cover,
      ),
    );
  }
}
