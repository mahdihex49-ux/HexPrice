import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';

import 'config.dart';

/// نگهداری و به‌روزرسانی لیست قیمت‌ها:
/// ۱) آخرین نسخه‌ی ذخیره‌شده روی گوشی (یا فایل داخل برنامه) فوری نمایش داده میشه
/// ۲) نسخه‌ی جدید از گیت‌هاب گرفته میشه و برای دفعه‌های بعد ذخیره میشه
class DataStore {
  static const String _cacheName = 'prices_cache.csv';

  static Future<File> _cacheFile() async {
    final dir = await getApplicationSupportDirectory();
    return File('${dir.path}/$_cacheName');
  }

  /// آخرین نسخه‌ی ذخیره‌شده، وگرنه نسخه‌ی داخل برنامه
  static Future<String> loadLocal() async {
    try {
      final f = await _cacheFile();
      if (await f.exists()) {
        final t = await f.readAsString();
        if (t.trim().isNotEmpty) return t;
      }
    } catch (_) {}
    return rootBundle.loadString('assets/prices.csv');
  }

  static Future<void> save(String text) async {
    try {
      final f = await _cacheFile();
      await f.writeAsString(text);
    } catch (_) {}
  }

  /// گرفتن فایل از گیت‌هاب؛ اگه نشد null
  static Future<String?> fetchRemote() async {
    if (kDataUrl.contains('__REPO__')) return null; // اجرای محلی، بدون آدرس
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 8);
    try {
      final stamp = DateTime.now().millisecondsSinceEpoch;
      final req = await client.getUrl(Uri.parse('$kDataUrl?t=$stamp'));
      final res = await req.close().timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) return null;
      return await res
          .transform(utf8.decoder)
          .join()
          .timeout(const Duration(seconds: 20));
    } catch (_) {
      return null;
    } finally {
      client.close(force: true);
    }
  }
}
