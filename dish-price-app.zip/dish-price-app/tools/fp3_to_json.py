#!/usr/bin/env python3
"""تبدیل فایل‌های .fp3 (خروجی لیست کالا از نرم‌افزار) به prices.csv

استفاده:
    python3 tools/fp3_to_json.py "مسیر/پوشه بکاپ ها"
بعد از اجرا فایل prices.csv با ستون‌های «لیست, کد, نام, قیمت» ساخته (یا جایگزین) میشه.
"""
import csv, glob, os, re, sys

# ترتیب نمایش لیست‌ها در برنامه: (شناسه، نام نمایشی)
ORDER = [
    ("tarh", "طرح"),
    ("rang-toranj", "رنگ ترنج"),
    ("tarh-golmorgh", "طرح گل و مرغ"),
    ("rang-golmorgh", "رنگ گل و مرغ"),
    ("touch-golmorgh", "تاچ گل و مرغ"),
    ("tashir", "تشعیر"),
    ("ghalamgiri", "قلم گیری تشعیر"),
    ("abrang", "آبرنگ تشعیر"),
    ("saye", "سایه تشعیر"),
    ("gereh", "گره"),
    ("bandkeshi", "بندکشی"),
    ("varagh-tala", "ورق طلا"),
    ("ghab", "قاب"),
]


def fa(s: str) -> str:
    """یکدست‌کردن ي/ك عربی به ی/ک فارسی و فاصله‌ها"""
    s = s.replace("ي", "ی").replace("ى", "ی").replace("ك", "ک")
    return re.sub(r"\s+", " ", s).strip()


def key(s: str) -> str:
    return fa(s).replace(" ", "").replace("\u200c", "")


def parse(path: str):
    text = open(path, encoding="utf-8").read()
    items = []
    for m in re.finditer(r'<b1 t="[^"]*"><s1/>(.*?)</b1>', text):
        vals = dict(re.findall(r'<m(\d+) u="([^"]*)"/>', m.group(1)))
        code, name = vals.get("1", ""), vals.get("2", "")
        try:
            price = int(float(vals.get("4", "0") or 0))
        except ValueError:
            price = 0
        items.append((code, name, price))
    return items


def main(folder: str):
    files = {}
    for f in glob.glob(os.path.join(folder, "**", "*.fp3"), recursive=True):
        files[key(os.path.splitext(os.path.basename(f))[0])] = f
    cats = []
    for cid, cname in ORDER:
        f = files.pop(key(cname), None)
        if not f:
            print("هشدار: فایل لیست پیدا نشد:", cname)
            continue
        cats.append((cid, cname, f))
    for i, (k, f) in enumerate(sorted(files.items())):  # فایل‌های اضافه
        cats.append((f"extra-{i+1}", fa(os.path.splitext(os.path.basename(f))[0]), f))

    rows = []
    for cid, cname, f in cats:
        # نام کالای اول هر لیست با اسم لیست شروع میشه، مثلا «طرح شکلات بزرگ»
        prefixes = [key(cname)]
        if cname == "آبرنگ تشعیر":
            prefixes.append("ابرنگتشعیر")
        count = 0
        for code, name, price in parse(f):
            n = fa(name)
            nk = n.replace(" ", "")
            for p in prefixes:
                if nk.startswith(p):
                    cut, seen = 0, 0
                    while cut < len(n) and seen < len(p):
                        if n[cut] != " ":
                            seen += 1
                        cut += 1
                    n = n[cut:].strip()
                    break
            if not n:
                continue
            rows.append((cname, code, n, price))
            count += 1
        print(f"{cname}: {count} کالا")

    # utf-8-sig تا اکسل فارسی رو درست نشون بده
    with open("prices.csv", "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["list", "code", "name", "price"])
        w.writerows(rows)
    print("prices.csv ساخته شد")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("مسیر پوشه‌ی فایل‌های fp3 رو بده")
    main(sys.argv[1])
